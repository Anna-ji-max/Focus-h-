# InstaFocus 1.2

This build removes Kotlin source files entirely. The app is Java-only so GitHub Actions builds `:app:assembleDebug` without a `compileDebugKotlin` task.

The overlay implementation also keeps windows alive between accessibility events instead of removing/recreating them on every event, preventing the blinking behavior from the earlier build.

Build with JDK 17 and Gradle 8.7. The workflow is `.github/workflows/android.yml`.


## v1.3 fixes
- Fixed `MainActivity` accessibility-service detection to use the public `AccessibilityServiceInfo.getResolveInfo()` API.
- Fixed invalid `Paint.create(...)` call by using `Typeface.create(...)`.
- Retained the anti-blinking overlay state logic from v1.2.
- No Kotlin source/plugin; build uses Java only.
